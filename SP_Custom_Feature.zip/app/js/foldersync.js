/* $Id$ */
var isMobileDevice = false;
var sharepoint = (function() {
    var self_component = null;
    var global = function() {
        this.recordData = {};
        this.allDriveItems = [];
        this.nextLink = [];
        this.recId = "";
        this.zsoid = "";
        this.attachment = {};
        this.constants = {
            "siteId": "SiteId", // <Field_API_Name>
            "driveId": "DriveId",//<Field_API_Name>
            "driveItemId": "DriveItemId",//<Field_API_Name>
            "folderPath": "https://zohoplugins.sharepoint.com/sites/contentTypeHub/Shared%20Documents/${Type}/${Status}" // ${Field_API_Name}
        }
    };
    var globalObj = new global();
    return {
        Init: function() {
            self_component = this;
            ZOHO.embeddedApp.on("PageLoad", function(data) {
                ZOHO.CRM.CONFIG.getOrgInfo().then(function(orgResponse) {
                    var zsoid = orgResponse.org[0].zgid;
                    globalObj.zsoid = zsoid;
                    globalObj.recId = data.EntityId;
                    globalObj.module = data.Entity;
                    ZOHO.CRM.API.getRecord({
                            Entity: globalObj.module,
                            RecordID: globalObj.recId
                        })
                        .then(function(data) {
                            globalObj.recordData = data.data[0];
                            $("#loader").removeClass("hide");
                            //name to be replaced as per custom field name

                            var folderSyncSiteId = globalObj.recordData.hasOwnProperty(globalObj.constants.siteId) && globalObj.recordData[globalObj.constants.siteId] ? globalObj.recordData[globalObj.constants.siteId] : null; 
                            var folderSyncDriveId = globalObj.recordData.hasOwnProperty(globalObj.constants.driveId) && globalObj.recordData[globalObj.constants.driveId] ? globalObj.recordData[globalObj.constants.driveId] : null; 
                            var folderSyncDriveItemId = globalObj.recordData.hasOwnProperty(globalObj.constants.driveItemId) && globalObj.recordData[globalObj.constants.driveItemId] ? globalObj.recordData[globalObj.constants.driveItemId] : null; 

                            //fetching org variable
                            var customModuleOrgVar = globalObj.constants.folderPath; //"https://zohoplugins.sharepoint.com/sites/Divya/Shared%20Documents/Folder1/${Account_Name} Account";
                            var baseFolder = customModuleOrgVar.split(/\/\$(.*)/s)[0];
                            var encodedWebUrl = "u!" + btoa(baseFolder).replace(/=+$/, '').replaceAll('/', '_').replaceAll('+', '-');

                            if (!folderSyncSiteId || !folderSyncDriveId || !folderSyncDriveItemId) {

                                var webUrlData = {
                                    "encodedWebUrl": encodedWebUrl
                                }
                                ZOHO.CRM.CONNECTOR.invokeAPI("sharepoint.sharepoint.getdriveitemusingweburl", webUrlData)
                                    .then(function(data) {
                                        console.log(data)
                                        if (data && data.status_code == 200) {
                                            var response = JSON.parse(data.response);
                                            var parentReference = response.parentReference;
                                            var siteId = parentReference.hasOwnProperty("siteId") ? parentReference.siteId : response.sharepointIds.siteId;
                                            var driveId = parentReference.driveId;
                                            var driveItemId = response.id;
                                            globalObj.siteId = siteId;
                                            globalObj.driveId = driveId;
                                            globalObj.driveItemId = driveItemId;
                                            const dynamicParamRegex = new RegExp(/\$\{(.+?)\}/g);
                                            var dynamicParamMatcher;
                                            var replacedContent = customModuleOrgVar;
                                            while (dynamicParamMatcher = dynamicParamRegex.exec(customModuleOrgVar)) {
                                                var apiName = dynamicParamMatcher[1];
                                                console.log(apiName);
                                                replacedContent = replacedContent.replace("${" + apiName + "}", globalObj.recordData[apiName]);
                                            }
                                            var directory = replacedContent.replace(baseFolder + "/", "");
                                            var createDirectoryData = {
                                                "id": siteId,
                                                "driveId": driveId,
                                                "itemId": "items/" + driveItemId,
                                                "directory": directory.replaceAll(" ", "%20"),
                                                "body": {
                                                    "folder": {},
                                                    "@microsoft.graph.conflictBehavior": "fail"
                                                }
                                            }
                                        }
                                        ZOHO.CRM.CONNECTOR.invokeAPI("sharepoint.sharepoint.createfolderdirectory", createDirectoryData)
                                            .then(function(data) {
                                                self_component.getFolderDirectoryDetails(createDirectoryData, data).then(function(data) {
                                                    self_component.getDriveItems(null).then(function(itemDetails) {
                                                        globalObj.allDriveItems = itemDetails.driveItems;
                                                        globalObj.currentDirectory = itemDetails.folderPath;
                                                        globalObj.nextLink = itemDetails.hasOwnProperty("nextLink") ? itemDetails.nextLink : null; 
                                                        self_component.constructDriveItemDetailsTable();
                                                        var splittedDirectory = globalObj.currentDirectory.split("/");
                                                        var breadcrumbs = '<span data-type="site">' + splittedDirectory[0] + '</span>';
                                                        breadcrumbs += '<span data-type="drive">' + splittedDirectory[1] + '</span>';

                                                        for (var i = 2; i < splittedDirectory.length; i++) {
                                                            breadcrumbs += '<span data-type="driveItem">' + splittedDirectory[i] + '</span>';
                                                        }
                                                        $("#breadcrumbs").empty().append(breadcrumbs);
                                                        globalObj.requestPending = false;
                                                        $("#driveItemDetails").removeClass("hide");
                                                        $("#loader").addClass("hide");
                                                    });
                                                });
                                            });
                                    })
                            }
                            else {
                                 globalObj.siteId = folderSyncSiteId;
                                 globalObj.driveId = folderSyncDriveId;
                                 globalObj.driveItemId = folderSyncDriveItemId;
                                 self_component.openDocLibrary();
                            }

                          
                        })
                })
                $("#newFile").click(function() {
                    $('#upload-pop-pane').addClass("hide");
                    self_component.showNewFileModal();
                });
            });
        },

        getFolderDirectoryDetails: function(createDirectoryData, data) {
            return new Promise((resolve, reject) => {
                if (data) {
                    var response = JSON.parse(data.response);
                    if (response.hasOwnProperty("error")) {
                        var errorCode = response.error.code;
                        if ("nameAlreadyExists" == errorCode) {
                            ZOHO.CRM.CONNECTOR.invokeAPI("sharepoint.sharepoint.getfolderdirectorydetails", createDirectoryData)
                                .then(function(data) {
                                    if (data && data.status_code == 200) {
                                        var response = JSON.parse(data.response);
                                        console.log(data);
                                        var parentReference = response.parentReference;
                                        var folderSyncDriveId = parentReference.driveId;
                                        var folderSyncSiteId = parentReference.siteId;
                                        var folderSyncDriveItemId = response.id;
                                        globalObj.siteId = folderSyncSiteId;
                                        globalObj.driveId = folderSyncDriveId;
                                        globalObj.driveItemId = folderSyncDriveItemId;
                                        var config = {
                                            Entity: globalObj.module,
                                            APIData: {
                                                id: globalObj.recId
                                            },
                                            Trigger: ["workflow"]
                                        }
                                        config.APIData[globalObj.constants.siteId] = globalObj.siteId;
                                        config.APIData[globalObj.constants.driveId] = globalObj.driveId;
                                        config.APIData[globalObj.constants.driveItemId] = globalObj.driveItemId;
                                        ZOHO.CRM.API.updateRecord(config)
                                            .then(function(data) {
                                                console.log(data);
                                                resolve("success");
                                            })

                                    }
                                })
                        }
                    } else {
                        var parentReference = response.parentReference;
                        var folderSyncDriveId = parentReference.driveId;
                        var folderSyncSiteId = parentReference.siteId;
                        var folderSyncDriveItemId = response.id;
                        globalObj.siteId = folderSyncSiteId;
                        globalObj.driveId = folderSyncDriveId;
                        globalObj.driveItemId = folderSyncDriveItemId;
                        var config = {
                            Entity: globalObj.module,
                            APIData: {
                                id: globalObj.recId
                            },
                            Trigger: ["workflow"]
                        }
                        config.APIData[globalObj.constants.siteId] = globalObj.siteId;
                        config.APIData[globalObj.constants.driveId] = globalObj.driveId;
                        config.APIData[globalObj.constants.driveItemId] = globalObj.driveItemId;
                        ZOHO.CRM.API.updateRecord(config)
                            .then(function(data) {
                                console.log(data);
                                resolve("success");
                            })
                    }
                }
            });
        },

        getDriveItems: function(nextLink) {
            return new Promise((resolve, reject) => {
                var driveItemData = {
                    "id": globalObj.siteId,
                    "driveId": globalObj.driveId,
                    "itemId": globalObj.driveItemId,
                };
                var isMoreRecords = false;
                var basePreviewUrl = null;
                var driveItemDetailsArr = [];
                var driveItemDetails = {};
                ZOHO.CRM.CONNECTOR.invokeAPI("sharepoint.sharepoint.getdriveitemdetails", driveItemData)
                    .then(function(data) {
                        console.log(data);
                        if (data && data.status_code == 200) {
                            var driveItemDetails = {};
                            var response = JSON.parse(data.response);
                            var webUrl = response.webUrl;
                            var docLibraryUrl = webUrl + "/";
                            var folderPath = "";
                            var domainRemovedWebUrl = self_component.removeDomainFromUrl(webUrl);
                            if (domainRemovedWebUrl && domainRemovedWebUrl.startsWith("sites")) {
                                folderPath = domainRemovedWebUrl.replace("sites/", ""); 
                                if (globalObj.driveItemId != "root") {
                                    docLibraryUrl = self_component.getDocLibraryUrl(webUrl, 6);
                                }
                            } else {
                                folderPath = domainRemovedWebUrl;
                                if (globalObj.driveItemId != "root") {
                                    docLibraryUrl = self_component.getDocLibraryUrl(webUrl, 4);
                                }
                            }
                            driveItemDetails.folderPath = decodeURI(folderPath);

                            driveItemDetails.folderUrl = webUrl;
                            var basePreviewUrl = docLibraryUrl + "Forms/AllItems.aspx?id="; 
                            driveItemData.top = 25;
                            var driveItemContents = "";
                            var namespace = "";
                            if (!nextLink) {
                                if ("root" == globalObj.driveItemId) {
                                    namespace = "sharepoint.sharepoint.getrootdrivechildren";
                                } else {
                                    namespace = "sharepoint.sharepoint.getrelativetorootdrivechildren";
                                }
                                ZOHO.CRM.CONNECTOR.invokeAPI(namespace, driveItemData)
                                    .then(function(data) {
                                        console.log(data);
                                        if (data && data.status_code == 200) {
                                            var response = JSON.parse(data.response);
                                            var driveContentsValues = response.value;
                                            var isMoreRecords = response.hasOwnProperty("@odata.nextLink") ? true : false; 
                                            var parentReference = "";
                                            for (var i = 0; i < driveContentsValues.length; i++) {
                                                var newItemObj = {};
                                                var itemObj = driveContentsValues[i];
                                                var isFolder = itemObj.hasOwnProperty("folder") ? true : false; 
                                                var preview = "-";
                                                var id = itemObj["id"];

                                                var fileNameWithExtension = itemObj["name"];
                                                var lastModifiedBy = itemObj.lastModifiedBy.user.displayName;
                                                if (i == 0) {
                                                    parentReference = itemObj.parentReference.id;
                                                }
                                                var createdOn = self_component.formatDate(itemObj.createdDateTime);
                                                var modifiedOn = self_component.formatDate(itemObj.lastModifiedDateTime);
                                                var fileType = "Folder"; 
                                                var size = 0;
                                                if (!isFolder) {
                                                    preview = decodeURI(itemObj.webUrl); //URLDecoder.decode(itemObj.getString("webUrl"), StandardCharsets.UTF_8.name());
                                                    size = itemObj.size;
                                                    fileType = fileNameWithExtension.substring(fileNameWithExtension.lastIndexOf(".") + 1, fileNameWithExtension.length);
                                                    if (!preview.includes("Doc.aspx")) {
                                                        var arr = preview.split('/');
                                                        var result = arr.slice(0,3);
                                                        var relativeFilePath = "/" + arr.slice(3).join("/");
                                                        var relativeFolderPath = relativeFilePath.split("/" + fileNameWithExtension)[0];
                                                        preview = basePreviewUrl + relativeFilePath + "&parent=" + relativeFolderPath; 
                                                    }
                                                }
                                                newItemObj.id = id;
                                                newItemObj.name = fileNameWithExtension
                                                newItemObj.fileType = fileType;
                                                newItemObj.lastModifiedBy = lastModifiedBy;
                                                newItemObj.createdOn = createdOn;
                                                newItemObj.modifiedOn = modifiedOn;
                                                newItemObj.size = isFolder ? "-" : self_component.humanFileSize(size);
                                                newItemObj.preview = preview;
                                                newItemObj.isFolder = isFolder;
                                                if (isMoreRecords) {
                                                    newItemObj.nextLink = itemObj["@odata.nextLink"];
                                                }
                                                driveItemDetailsArr.push(newItemObj);
                                            }
                                            driveItemDetails.driveItems = driveItemDetailsArr;
                                            if ("root" == globalObj.driveItemId) {
                                                driveItemDetails.parentReference = parentReference;
                                            }
                                            resolve(driveItemDetails);
                                        }
                                    });
                            } else {
                                var url = nextLink.replace("https://graph.microsoft.com/", ""); 
                                namespace = "sharepoint.sharepoint.getnextpagedetails";
                                var nextPageData = {
                                    "url": url
                                };
                                ZOHO.CRM.CONNECTOR.invokeAPI(namespace, nextPageData)
                                    .then(function(data) {
                                        console.log(data);
                                    });
                            }
                        }
                    });
            })
        },
        formatDate: function(inputDate) {
            const date = new Date(inputDate);

            // Format the date
            const day = date.getDate();
            const month = date.toLocaleString('default', {
                month: 'short'
            });
            const year = date.getFullYear();

            // Format the time
            let hours = date.getHours();
            const minutes = ('0' + date.getMinutes()).slice(-2);
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // Handle midnight (0 hours)

            // Construct the formatted date string
            const formattedDate = `${day} ${month} ${year} ${hours}:${minutes} ${ampm}`;

            return formattedDate;
        },
        humanFileSize: function(bytes) {
            var thresh = 1024;
            if (Math.abs(bytes) < thresh) {
                return bytes + ' B'; 
            }
            var units = ['kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB']; 
            var u = -1;
            do {
                bytes /= thresh;
                ++u;
            } while (Math.abs(bytes) >= thresh && u < units.length - 1);
            return bytes.toFixed(1) + ' ' + units[u];
        },
        removeDomainFromUrl: function(webUrl) {
            var regEx = new RegExp("^(?:[^\\/\\n]*\\/){3}(.*)$");
            var result = regEx.exec(webUrl);
            return result ? result[1] : null;
        },
        getDocLibraryUrl: function(webUrl, position) {
            var regEx = new RegExp("(?:[^\\/]*\\/){" + position + "}");
            var result = regEx.exec(webUrl);
            return result ? result[0] : null;
        },
        openDocLibrary: function() {
            $("#loader").removeClass("hide");
            self_component.getDriveItems(null).then(function(itemDetails) {
                globalObj.allDriveItems = itemDetails.driveItems;
                globalObj.currentDirectory = itemDetails.folderPath;
                globalObj.nextLink = itemDetails.hasOwnProperty("nextLink") ? itemDetails.nextLink : null;
                self_component.constructDriveItemDetailsTable();
                var splittedDirectory = globalObj.currentDirectory.split("/");
                var breadcrumbs = '<span data-type="site">' + splittedDirectory[0] + '</span>';
                breadcrumbs += '<span data-type="drive">' + splittedDirectory[1] + '</span>';

                for (var i = 2; i < splittedDirectory.length; i++) {
                    breadcrumbs += '<span data-type="driveItem">' + splittedDirectory[i] + '</span>';
                }
                $("#breadcrumbs").empty().append(breadcrumbs);
                globalObj.requestPending = false;
                $("#driveItemDetails").removeClass("hide");
                $("#loader").addClass("hide");
            });
},
constructDriveItemDetailsTable: function() {
    if (!globalObj.requestPending) {
        $("#listDetailsTbl tbody").empty();
    }
    if (globalObj.allDriveItems != null && globalObj.allDriveItems.length > 0) {
        globalObj.allDriveItems.map(function(driveItem) {
            var tbodyDetails = "";
            var name = driveItem.name;
            var fileType = driveItem.fileType;
            var lastModifiedBy = driveItem.lastModifiedBy;
            var createdOn = driveItem.createdOn;
            var modifiedOn = driveItem.modifiedOn;
            var size = driveItem.size;
            var preview = driveItem.preview;
            tbodyDetails = "<tr><td class='left'><div><a class='preview' href='javascript:void(0);'>" + name + "</a></div></td><td><div>" + fileType + "</div></td><td><div>" + lastModifiedBy + "</div></td><td><div>" + createdOn + "</div></td><td><div>" + modifiedOn + "</div></td><td><div>" + size + "</div></td></tr>";
            tbodyDetails = $(tbodyDetails);
            tbodyDetails.find(".preview").click(function(e) {
                window.open(preview, "_blank");
                e.stopPropagation();
            });
            $("#listDetailsTbl tbody").append(tbodyDetails);
        })

    } else if (!globalObj.requestPending) {
        var tbodyDetails = "<tr><td class='nodata' colspan='6'><div class='center'>No data available</div></td></tr>";
        $("#listDetailsTbl tbody").empty().append(tbodyDetails);
    }

},

showNewFileModal: function() {
    var fileDialog = '<div id="createDocumentMainSection">' +
        '<div class="hide" id="upload-pop-pane">' +
        '<div class="popupContainer">' +
        '<div class="icon"></div>' +
        '<div class="msgContainer">' +
        '<div class="action-close">' +
        '<i class="closeIcon">x</i>' +

        '</div>' +
        '<div class="action-data" id="upload-pop-data"></div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div id="createDocSection">' +
        '<table style="table-layout:fixed" id="createDocTbl" class="w100">' +
        '<tbody>' +
        '<tr>' +
        '<td>' +
        '<label class="bold">Documents</label>' + 

        '</td>' +
        '<td>' +
        '</td>' +
        '</tr>' +

        '<tr>' +
        '<td>' +
        '<label>Choose Document</label>' + 

        '</td>' +
        '<td>' +
        '<div class="pT10">' +
        '<div class="addBtn" id="addDocument" style="width:200px">' +
        '<div style="width:100px">' +
        '<a href="javascript:void(0)" id="uploadFile" class="browse">Browse</a>' +

        '</div>' +
        /*  '<div>' +
           '<ul class="dropdown addDocumentDropdown hide">' +
           '<li>' +
           '<a href="javascript:void(0)" id="uploadFile">From Desktop</a>' +

           '</li>' +
           '<li>' +
           '<a href="javascript:void(0)" id="addCrmDocument">From CRM Documents</a>' +

           '</li>' +
           '</ul>' +
           '</div>' + */
        '</div>' +
        '</div>' +
        '<div class="pT10 hide">' +
        '<input type="file" id="fileUpload" name="attachment" class="hide" />' +
        '</div>' +
        '</td>' +
        '</tr>' +
        '<tr id="documentPlaceholder">' +
        '</tr>' +
        '</tbody>' +
        '</table>' +
        '</div>' +

        '<div style="padding:10px;margin-top:10px;background:#FDFAF2">' +
        '<div class="bold">Notes:</div>' +

        '<ul id="noteList">' +
        '<li>These names aren\'t allowed for files or folders: <span class="bold">.lock, CON, PRN,AUX, NUL, COM0 - COM9, LPT0 - LPT9, _vti_, desktop.ini</span></li>' + 
        '<li><span class="bold">"_vti_" </span>cannot appear anywhere in a file name</li>' +

        '<li><span class="bold">"forms" </span>isn\'t supported when the folder is at the root level for a library.</li>' +
        '   <li>You can\'t create a folder name in SharePoint that begins with a tilde (~)</li>' + 
        '</ul>' +
        '</div>' +

        '<div style="float:right;margin-top:10px" class="">' +
        '<div class="inline-block">' +
        '<button class="cancelBtn" name="Cancel" id="createDocCancelId">Cancel</button>' + 

        '</div>' +
        '<div class="inline-block mL10">' +
        '<button class="saveBtn" name="Save" disabled id="uploadDocSave">Save</button>' + 

        '</div>' +
        '</div>' +
        '</div>';

    $("body").append(
        "<div id='fileDialog'>" + fileDialog + "</div>"
    );
    if (isMobileDevice) {
        $("#documentPlaceholder").append(
            '<td colspan="2">' +
            '<div id="documents"></div>' +
            '</td>');
    } else {
        $("#documentPlaceholder").append('<td></td>' +
            '<td>' +
            '<div id="documents"></div>' +
            '</td>');
    }
    globalObj.attachment= {};
    $("#uploadDocSave").prop("disabled", true);

    self_component.attachNewFileListeners();

    $("#fileDialog").dialog({
        modal: true,
        title: "Create Document",
        buttons: {},
        minWidth: "320",
        maxWidth: "768",
        width: "90%",
        minHeight: "320",
        open: function(event, ui) {
            
            $("#fileDialog")
                .parent()
                .addClass("sharepointDialog")
                .prev();
            $(this).dialog({
                position: {
                    my: "center",
                    at: "center",
                    of: window
                }
            });

        },
        close: function(event, ui) {
            $(this).dialog("close");
            $("#fileDialog").remove();
        }
    });
},
attachNewFileListeners: function() {
    $("#createDocumentMainSection")
        .find(".cancelBtn")
        .click(function() {
            $("#fileDialog").dialog("close");
        });
    $("#createDocumentMainSection")
        .find(".saveBtn")
        .click(function() {
            self_component.uploadDocument();
        });
    $("#createDocumentMainSection")
        .find(".action-close .closeIcon")
        .click(function() {
            self_component.closeMessagePopup("upload-pop"); 
        });
    $("#createDocumentMainSection")
        .find("#uploadFile")
        .click(function() {
            if (Object.keys(globalObj.attachment).length == 0) {
                $("#fileUpload").click();
            }
        });

    $("#createDocumentMainSection")
        .find("#fileUpload")
        .click(function() {
            this.value = null;
        });
    $("#createDocumentMainSection")
        .find("#fileUpload")
        .change(function() {
            var file = $("#fileUpload").get(0).files[0]; 
            var size = $("#fileUpload").get(0).files[0].size; 
            var sizeMB = size / (1024 * 1024).toFixed(2);
            if (sizeMB > 4) {
                self_component.showMessagePopup("upload-pop", "failure", "File size exceeds 4MB"); 
            } else if (sizeMB === 0) {
                self_component.showMessagePopup("upload-pop", "failure", "Please upload file of valid size"); 
            } else {
                var uploadId = self_component.addFileEntry(file.name);
                if (uploadId !== "") {
                    var fileInfo = {};
                    fileInfo.type = "localfile";
                    fileInfo.file_name = file.name;
                    fileInfo.file_obj = file;
                    globalObj.attachment = fileInfo;
                }
            }
        });
},
uploadDocument: function() {
    $("#uploadDocSave").prop("disabled", true);
    ZOHO.CRM.API.getRecord({
            Entity: globalObj.module,
            RecordID: globalObj.recId
        })
        .then(function(data) {
            globalObj.recordData = data.data[0];
            var selectedSiteId = globalObj.recordData[globalObj.constants.siteId];
            var selectedDriveId = globalObj.recordData[globalObj.constants.driveId];
            var selectedFolderId = globalObj.recordData[globalObj.constants.driveItemId];
            var formData = new FormData();
            var data = {
                "VARIABLES": {
                    "id": selectedSiteId,
                    "driveId": selectedDriveId,
                    "itemId": selectedFolderId,
                    "fileName": encodeURI(globalObj.attachment.file_name),
                    "file_name": encodeURI(globalObj.attachment.file_name)
                },
                "CONTENT_TYPE": "multipart",
                "FORWARD_TYPE": "data-binary",
                "FILE": {
                    "fileParam": "content",
                    "file": globalObj.attachment.file_obj
                },
            }
            ZOHO.CRM.CONNECTOR.invokeAPI("sharepoint.sharepoint.uploadfile", data)
                .then(function(data) {
                    self_component.showMessagePopup("upload-pop", "success", "File uploaded successfully"); 
                })
        });
},
showMessagePopup: function(type, className, message) {
    $('#' + type + '-pane').removeClass(); 
    $('#' + type + '-data').html(message); 
    if (className == "failure") {
        $('#' + type + '-pane').find(".icon").removeClass("successIcon").addClass("failureIcon");  
    } else {
        $('#' + type + '-pane').find(".icon").removeClass("failureIcon").addClass("successIcon");  
    }
    $('#' + type + '-pane').addClass('action-pane ' + className); 
    $('#' + type + '-pane').animate({
        top: "5px" 
    }).show();
    if (className == "success" && type != "common-pop") {
        $(function() {
            setTimeout(function() {
                if (type == "upload-pop") {
                    $("#fileDialog").dialog("close");
                    self_component.openDocLibrary();
                }

            }, 2000);
        });
    } else {
        $(function() {
            setTimeout(function() {
                self_component.closeMessagePopup(type);
            }, 4000);
        });
    }
},
closeMessagePopup: function(type) {
    $('#' + type + '-pane').animate({
        top: "-100%"
    });
    setTimeout(function() {
        $('#' + type + '-pane').hide(); 
    }, 4000);
},
addFileEntry: function(fileName) {
    var fileExtn = "";
    if (fileName.lastIndexOf(".") != -1) {
        fileExtn = fileName.substring(fileName.lastIndexOf('.') + 1);
    }
    if (fileExtn == "") {
        return "";
    }
    var uploadId = Math.random().toString(36).substr(2, 9);
    $("#documents").append('<div id="' + uploadId + '-div" class="uploaded-file-list"><div><div><span class="uploaded-file-name">' + fileName + ' </span><span title="Remove File" style="float: right; padding: 2px;"><a href="javascript:void(0);" id="removeAttachment">Remove</a></span></div></div></div>'); 
    $("#fileDialog").dialog({
        position: {
            my: "center",
            at: "center",
            of: window
        }
    });
    var regEx = new RegExp(/^(?:~.*|aux|con|nul|prn|com[0-9]|lpt[0-9]|.*_vti_.*|desktop\.ini|\.lock)$/i);
    var result = regEx.exec(fileName);
    if (result != null && result.length > 0) {
        $("#uploadDocSave").prop("disabled", true);
    } else {
        $("#uploadDocSave").prop("disabled", false);
    }
    $(".uploaded-file-list  #removeAttachment").click(function() {
        self_component.removeFileEntry(uploadId);
    });
    return uploadId;
},
removeFileEntry: function(id) {
    $("#" + id + "-div").remove();
    globalObj.attachment = {};
    $("#uploadDocSave").prop("disabled", true);
}
}
})();
$(document).ready(function() {
    if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) ||
        /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))) {
        isMobileDevice = true;
    } else {
        isMobileDevice = false;
    }
    sharepoint.Init();
    ZOHO.embeddedApp.init();
});